Testing
=======

The testcases work by using the Nayuki QR code generating library, generating a QR code
in both libraries and comparing them.

Running
-------

```
./run.sh
```
